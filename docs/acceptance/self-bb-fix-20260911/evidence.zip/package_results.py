"""修正後の実測結果と元byte列を保存し、自己BBの修正受入を記録する。"""
import hashlib
import json
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parents[1]
dest = repo / "docs/acceptance/self-bb-fix-20260911"

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def digest(data):
    return hashlib.sha256(data).hexdigest()

raw = read(lab / "results.json")
assert raw["counts"] == {"pass": 45, "fail": 0, "blocked": 0, "observed": 5}
assert raw["commands"] == 58
cases = {row["id"]: row for row in raw["results"]}
assert cases["CH-01-bom"]["details"]["counts"]["requirements"] == 1
assert cases["CH-01-bom"]["details"]["score"] == 69
assert cases["BB-32"]["details"]["requests"] == []
assert cases["BB-32"]["details"]["usage"]["calls"] == 0
assert cases["BB-38"]["details"]["status"] == "no_go"
value = {
    "target": "4.1.0 + self-BB fixes; local unreleased wheel",
    "verified_at": datetime.now(timezone.utc).isoformat(),
    "base_commit": "6149d81fee17b6271503717b3fc2c0f6a738a540",
    "bb": {"pass": 45, "fail": 0, "blocked": 0, "exploration_observed": 5, "cli_calls": 58},
    "pytest": {"passed": 1117, "coverage_percent": read(lab / "coverage-all.json")["totals"]["percent_covered"]},
    "gate_pytest": {"passed": 116, "coverage_percent": read(lab / "coverage-gate.json")["totals"]["percent_covered"]},
    "fix_acceptance": "pass",
    "release_status": "unreleased; no GitHub Actions rerun, merge, or PyPI publication",
    "llm_calls": 0,
    "resolved_findings": [
        {"id": "MBB-BB-001", "status": "fixed_and_retested", "cases": ["BB-31", "BB-32"]},
        {"id": "MBB-BB-002", "status": "fixed_and_retested", "cases": ["CH-01-bom"]},
        {"id": "MBB-BB-003", "status": "fixed_and_retested", "cases": ["BB-38"]},
    ],
    "runner_finalization": read(lab / "finalization.json"),
    "cases": raw["results"],
}
with (dest / "final-results.json").open("x", encoding="utf-8") as stream:
    stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")

entries = {}
for folder in ("commands", "work"):
    for path in (lab / folder).rglob("*"):
        if path.is_file():
            entries[path.relative_to(lab).as_posix()] = path.read_bytes()
for name in ("results.json", "bb.log", "finalization.json", "package-verification.json", "pytest-all.log",
             "pytest-all.xml", "coverage-all.json", "pytest-gate.log", "pytest-gate.xml", "coverage-gate.json",
             "validate-artifacts.log", "prepare_retest.py", "package_results.py"):
    entries[name] = (lab / name).read_bytes()
for name in ("runner.py", "report.md", "final-results.json"):
    entries["session/" + name] = (dest / name).read_bytes()
changed = subprocess.check_output(["git", "diff", "--name-only"], cwd=repo, text=True).splitlines()
changed.append("tests/test_markdown_input_compatibility.py")
for name in changed:
    entries["source/" + name] = (repo / name).read_bytes()
entries["tracked-fix.patch"] = subprocess.check_output(["git", "diff", "--binary"], cwd=repo, stderr=subprocess.DEVNULL)
archive = dest / "evidence.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(entries.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, data in entries.items():
        assert z.read(name) == data, name
manifest = {
    "archive": archive.name, "size": archive.stat().st_size, "sha256": digest(archive.read_bytes()),
    "files": [{"path": name, "size": len(data), "sha256": digest(data)} for name, data in sorted(entries.items())],
    "verification": "元のbyte列と全収録ファイルを比較、CRCとSHA-256検証済み",
}
with (dest / "evidence-manifest.json").open("x", encoding="utf-8") as stream:
    stream.write(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"files": len(entries), "size": manifest["size"], "sha256": manifest["sha256"]}))
