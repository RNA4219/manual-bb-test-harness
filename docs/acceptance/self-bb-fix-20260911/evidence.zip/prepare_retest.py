"""初回runnerを保持し、確認済みの試験前提だけを直した再試験版を作る。"""
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
original = repo / "docs/acceptance/self-bb-4.1.0/runner.py"
target = repo / "docs/acceptance/self-bb-fix-20260911/runner.py"
text = original.read_text(encoding="utf-8")
replacements = [
    ('"bb-harness 4.1.0 from PyPI"', '"bb-harness 4.1.0 + self-BB fixes (local wheel, unreleased)"'),
    ('"requirements", "confirmations"', '"requirements", "issues"'),
    ('first.get(key) == second.get(key)', 'key in first and key in second and first[key] == second[key]'),
    ('review["resolutions"] = [{"issue_id": "F-1",', 'review["resolutions"] = [{"issue_id": "review:F-1",'),
    ('            cases = s.write("fixtures/discount/damaged.json", value)\n',
     '            cases = s.write("fixtures/discount/damaged.json", value)\n'
     '            binding = s.call(["bind-cases", "--input", cases, "--test-model", "fixtures/discount/discount.test_model.json", "--output", "fixtures/discount/rebound.json"])\n'
     '            require(binding.returncode == 0, "modified case rebind succeeds", binding.stderr)\n'
     '            cases = "fixtures/discount/rebound.json"\n'),
    ('    def gate():\n        base = s.repo / "examples/artifacts"\n',
     '    def gate():\n        base = s.repo / "examples/artifacts"\n'
     '        (s.work / "fixtures/empty-evidence").mkdir()\n'),
    ('"--build-id", "self-bb-4.1.0", "--output", "outputs/gate.json"]',
     '"--evidence", "fixtures/empty-evidence", "--build-id", "self-bb-4.1.0", "--output", "outputs/gate.json"]'),
]
for before, after in replacements:
    assert text.count(before) == 1, before
    text = text.replace(before, after)
target.parent.mkdir(exist_ok=False)
with target.open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(text)
print(target)
