"""自己BBの初回・再試験を追跡可能な最終判定へ集約する。製品の期待値は変更しない。"""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parents[1]
dest = repo / "docs/acceptance/self-bb-4.1.0"

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

initial = read(lab / "results.json")
followup = read(lab / "followup-results.json")
by_id = {row["id"]: row for row in followup["results"]}
first = read(lab / "work/outputs/unreviewed/requirements_confidence.json")
second = read(lab / "work/outputs/repeat/requirements_confidence.json")
for key in ("input_sha256", "score", "counts", "requirements", "issues"):
    assert key in first and key in second and first[key] == second[key], key
assert first["requirements"]

p0 = {26, 27, 28, 33, 37}
p2 = {31, 32, 39, 40, 41, 42, 43, 44}
corrected = {"BB-14": "BB-14-corrected", "BB-35": "BB-35-corrected"}
bug_cases = {"BB-31": "MBB-BB-001", "BB-32": "MBB-BB-001", "BB-38": "MBB-BB-003"}
rows = []
for raw in initial["results"]:
    if not raw["id"].startswith("BB-"):
        continue
    identifier = raw["id"]
    number = int(identifier[3:])
    result = raw["result"]
    source = f"evidence.zip!commands/{raw['commands'][0]:03d}.json"
    note = None
    if identifier in corrected:
        replacement = corrected[identifier]
        assert by_id[replacement]["result"] == "pass"
        result = "pass"
        source = "evidence.zip!followup-results.json#" + replacement
        note = "初回の入力準備を修正し、計画済みの同じ期待結果で再確認"
    elif identifier == "BB-38":
        assert by_id["BB-38-corrected-empty"]["result"] == "fail"
        source = "evidence.zip!followup-results.json#BB-38-corrected-empty"
        note = "正式な--input導線でも証跡0件のno_goレポートが生成されない"
    elif identifier == "BB-29":
        note = "初回runnerのconfirmationsは存在しないキー。保存されたissuesの存在と一致を追加照合した"
    elif identifier == "BB-32":
        assert by_id["BB-32-ascii-control"]["result"] == "pass"
        note = "元の日本語名では取込エラー。ASCII名対照では予算停止・生成0回を確認"
    rows.append({"id": identifier, "priority": "P0" if number in p0 else "P2" if number in p2 else "P1",
                 "initial_result": raw["result"], "final_result": result,
                 "defect_id": bug_cases.get(identifier), "evidence": source, "note": note})

assert len(rows) == 45
assert sum(row["final_result"] == "pass" for row in rows) == 42
assert sum(row["final_result"] == "fail" for row in rows) == 3
defects = [
    {"id": "MBB-BB-001", "title": "日本語だけのファイル名でLocal Modeのfeature_idが空になり停止",
     "severity": "medium", "fix_priority": "P1", "status": "open", "cases": ["BB-31", "BB-32"],
     "basis": "同一本文のASCII名・日本語ディレクトリ内ASCII名・混在名は成功、日本語のみは失敗"},
    {"id": "MBB-BB-002", "title": "UTF-8 BOM付きMarkdownの先頭要件見出しを読み落とす",
     "severity": "medium", "fix_priority": "P1", "status": "open", "cases": ["CH-01-bom"],
     "basis": "BOM有無だけを変えた対照で要件数1→0、score69→null。互換性期待に基づく不具合"},
    {"id": "MBB-BB-003", "title": "証跡0件のGate CLIがno_goレポートを生成しない",
     "severity": "medium", "fix_priority": "P2", "status": "open", "cases": ["BB-38"],
     "basis": "READMEの未実施評価・終了コード契約と、--input/--evidenceの実動作が不一致。誤Goはなし"},
]
value = {
    "target": "bb-harness==4.1.0 (public PyPI wheel)",
    "base_commit": "6149d81fee17b6271503717b3fc2c0f6a738a540",
    "reviewed_at": datetime.now(timezone.utc).isoformat(),
    "method": "manual-bb-test-harness Skillによる仕様ベース設計と、Codex操作のCLIブラックボックス試験",
    "initial_scripted": {"pass": 40, "fail": 5, "total": 45},
    "final_scripted": {"pass": 42, "fail": 3, "blocked": 0, "total": 45},
    "by_priority": {priority: {result: sum(row["priority"] == priority and row["final_result"] == result for row in rows)
                                 for result in ("pass", "fail")}
                    for priority in ("P0", "P1", "P2")},
    "exploration": {"observed_rejections": ["nan", "inf", "-1", "101"], "confirmed_defects": ["MBB-BB-002"]},
    "cli_invocations": {"initial_including_4_setup": 57, "triage": 10, "followup": 7, "total": 74},
    "llm_generation_calls": 0,
    "gate": {"status": "no_go", "kind": "reviewer_decision", "profile_reference": "standard",
             "reason": "P1全件passという今回の受入条件を満たさず、未修正3件が残る",
             "release_action": "none", "is_sut_gate_output": False},
    "defects": defects, "cases": rows,
    "limitations": ["Windows/Python3.13だけを今回実行", "実LLM生成品質は未検収を引継ぎ",
                    "実案件による採点policy校正は未実施", "HATE/QEG全連携の再実行は今回の対象外",
                    "独立した人の手動受入ではない"],
}
with (dest / "final-results.json").open("x", encoding="utf-8") as stream:
    stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({key: value[key] for key in ("final_scripted", "by_priority", "gate")}, ensure_ascii=False))
