"""合成BB証跡の元byte列をzipへ保存し、展開せず全項目をhash照合する。"""
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parents[1]
dest = repo / "docs/acceptance/self-bb-4.1.0"
entries = {}
for directory in ("commands", "work"):
    for path in (lab / directory).rglob("*"):
        if path.is_file():
            entries[path.relative_to(lab).as_posix()] = path.read_bytes()
for name in ("results.json", "triage-probes.json", "followup-results.json", "package-verification.json", "run.log", "triage.log"):
    path = lab / name
    if path.exists():
        entries[name] = path.read_bytes()
for name in ("plan.md", "runner.py", "followup_checks.py", "report.md", "final-results.json"):
    entries["session/" + name] = (dest / name).read_bytes()
for name in ("triage_probes.py", "assemble_report.py", "package_evidence.py"):
    entries["scripts/" + name] = (lab / name).read_bytes()
for path in (lab / "installed").glob("*.json"):
    entries["installation/" + path.name] = path.read_bytes()

# 元の対照入力のbyte列を使い、Gateだけ実行前の証跡0件ディレクトリを復元する。
for name, original in (("ascii.md", "ascii-complete.md"), ("日本語.md", "日本語完全.md"),
                       ("plain.md", "no-bom.md"), ("bom.md", "with-bom.md")):
    entries["reproduction-inputs/" + name] = (lab / "work/probes" / original).read_bytes()
for kind in ("feature_spec", "risk_register", "manual_case_set"):
    name = f"order-cancel.{kind}.json"
    entries["reproduction-inputs/gate-empty/" + name] = (repo / "examples/artifacts" / name).read_bytes()

assert entries["reproduction-inputs/ascii.md"] == entries["reproduction-inputs/日本語.md"]
assert entries["reproduction-inputs/bom.md"] == b"\xef\xbb\xbf" + entries["reproduction-inputs/plain.md"]
archive = dest / "evidence.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, data in sorted(entries.items()):
        bundle.writestr(name, data)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert sorted(bundle.namelist()) == sorted(entries)
    for name, data in entries.items():
        assert bundle.read(name) == data, name
manifest = {
    "created_at": datetime.now(timezone.utc).isoformat(),
    "archive": archive.name,
    "size": archive.stat().st_size,
    "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "files": [{"path": name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
              for name, data in sorted(entries.items())],
    "verification": "全収録byte列と元データを比較済み、zip CRC正常",
    "data_classification": "合成試験データとコマンド証跡。SUT入力の合成execution evidenceは自己BBの実測結果ではない",
}
with (dest / "evidence-manifest.json").open("x", encoding="utf-8") as stream:
    stream.write(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"files": len(entries), "bytes": manifest["size"], "sha256": manifest["sha256"]}))
