"""初回BBの差分を公開CLIで単一要因へ絞る。初回証跡は変更しない。"""
import copy
import json
import os
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parents[1]
work = root / "work"
sut = root / "installed/venv/Scripts/bb-harness.exe"
env = os.environ.copy()
env["PYTHONUTF8"] = "1"
env.pop("PYTHONPATH", None)
results = []

def write(path, value):
    target = work / path
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2))
    return path

def call(name, args):
    result = subprocess.run([str(sut), *map(str, args)], cwd=work, env=env,
                            capture_output=True, encoding="utf-8", timeout=30)
    entry = {"name": name, "args": list(map(str,args)), "code": result.returncode,
             "stdout": result.stdout, "stderr": result.stderr}
    results.append(entry)
    print(json.dumps(entry, ensure_ascii=False), flush=True)
    (root / "triage-probes.json").write_text(json.dumps(results, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    return result

minimal = (work / "fixtures/日本語 空白.md").read_text(encoding="utf-8")
complete = (repo / "examples/local-benchmark/minimal-cancel.md").read_text(encoding="utf-8")
for name, text in (("ascii-minimal", minimal), ("ascii-complete", complete), ("日本語完全", complete)):
    path = write(f"probes/{name}.md", text)
    call(name, ["run", "local-design", "--input", path, "--output", f"probes/out-{name}",
                "--profile", "generic", "--model", "self-bb-model", "--generation-mode", "batched", "--estimate-only"])

review = json.loads((work / "reviews/resolved.json").read_text(encoding="utf-8"))
review["resolutions"] = []
write("probes/open-review.json", review)
call("resolution-open", ["evaluate", "requirements", "--input", "fixtures/n2.json", "--review", "probes/open-review.json", "--output", "probes/open"])
opened = json.loads((work / "probes/open/requirements_confidence.json").read_text(encoding="utf-8"))
review["resolutions"] = [{"issue_id": opened["issues"][0]["issue_id"], "decision": "合成試験は保存完了後に次の値を保存する。",
                          "source_refs": review["requirements"][0]["source_refs"]}]
write("probes/closed-review.json", review)
call("resolution-closed", ["evaluate", "requirements", "--input", "fixtures/n2.json", "--review", "probes/closed-review.json", "--output", "probes/closed"])

call("rebind-damaged", ["bind-cases", "--input", "fixtures/discount/damaged.json", "--test-model", "fixtures/discount/discount.test_model.json", "--output", "probes/rebound.json"])
coverage = ["coverage", "--feature", "fixtures/discount/discount.feature_spec.json", "--test-model", "fixtures/discount/discount.test_model.json",
            "--observations", "fixtures/discount/discount.observation_set.json", "--risk", "fixtures/discount/discount.risk_register.json",
            "--cases", "probes/rebound.json", "--output", "probes/coverage", "--build-id", "demo-1"]
call("coverage-after-rebind", coverage)

(work / "probes/empty-evidence").mkdir()
base = repo / "examples/artifacts"
call("gate-empty-evidence", ["gate", "--feature", str(base / "order-cancel.feature_spec.json"), "--risk", str(base / "order-cancel.risk_register.json"),
                             "--cases", "fixtures/old-cases.json", "--evidence", "probes/empty-evidence", "--build-id", "self-bb-4.1.0", "--output", "probes/gate.json"])

for name, prefix in (("no-bom", ""), ("with-bom", "\ufeff")):
    path = write(f"probes/{name}.md", prefix + "## 要件\n- AC-1: 保存後に完了と表示する。\n")
    call(name, ["evaluate", "requirements", "--input", path, "--output", "probes/out-"+name])
